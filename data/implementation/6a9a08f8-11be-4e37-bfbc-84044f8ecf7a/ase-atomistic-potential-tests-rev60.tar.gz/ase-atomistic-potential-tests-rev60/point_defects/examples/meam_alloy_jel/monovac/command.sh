PATH=$PATH:../../..
PYTHONPATH=$PYTHONPATH:.

monovac.py Al fcc 4.05  > results/log.Al.fcc
monovac.py Si dia 5.431 > results/log.Si.dia
monovac.py Cu fcc 3.62  > results/log.Cu.fcc
monovac.py Fe bcc 2.851 > results/log.Fe.bcc
monovac.py Mg hcp 3.2027793 0.991824332358 > results/log.Mg.hcp
