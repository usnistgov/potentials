PATH=$PATH:../../..
PYTHONPATH=$PYTHONPATH:.

interst.py Al fcc tetr   4.05  > results/log.Al.fcc.tetr
interst.py Cu fcc tetr   3.62  > results/log.Cu.fcc.tetr
interst.py Mg hcp tetr   3.2027793 0.991824332358 > results/log.Mg.hcp.tetr
interst.py Fe bcc tetr   2.851 > results/log.Fe.bcc.tetr
                              
interst.py Al fcc octa   4.05  > results/log.Al.fcc.octa
interst.py Cu fcc octa   3.62  > results/log.Cu.fcc.octa
interst.py Mg hcp octa   3.2027793 0.991824332358 > results/log.Mg.hcp.octa
interst.py Fe bcc octa   2.851 > results/log.Fe.bcc.octa
interst.py Fe bcc dum111 2.851 > results/log.Fe.bcc.dum111
interst.py Fe bcc dum100 2.851 > results/log.Fe.bcc.dum100
                              
interst.py Cu fcc dumb   3.62  > results/log.Cu.fcc.dumb
interst.py Al fcc dumb   4.05  > results/log.Al.fcc.dumb
interst.py Fe bcc dumb   2.851 > results/log.Fe.bcc.dumb
interst.py Mg hcp dumb   3.2027793 0.991824332358 > results/log.Mg.hcp.dumb
interst.py Si dia dumb   5.431 > results/log.Si.dia.dumb
