PATH=$PATH:../../..
PYTHONPATH=$PYTHONPATH:.

interst.py Cu fcc tetr 3.63908232 > results/log.Cu.fcc.tetr
interst.py Cu fcc octa 3.63908232 > results/log.Cu.fcc.octa
interst.py Cu fcc dumb 3.63908232 > results/log.Cu.fcc.dumb
